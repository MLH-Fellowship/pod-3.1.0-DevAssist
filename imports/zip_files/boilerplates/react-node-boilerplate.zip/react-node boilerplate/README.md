# React + Express Development Boilerplate


## How to Use
Firstly, download [Docker desktop](https://www.docker.com/products/docker-desktop) and follow its
 instructions to install it. This allows us to start using Docker containers.
 
Then run 

    docker-compose build
    
This spins up Compose and builds a local development environment according to 
our specifications in [docker-compose.yml](docker-compose.yml). 

After the containers have been built (this may take a few minutes), run

    docker-compose up
    
This one command boots up a local server for Express (on port 8080)
and React (on port 80). Head over to

    http://localhost:8080
    
    and

    http://localhost:80/api
    


Finally, to gracefully stop running our local servers, you can run
 
    docker-compose down

in a separate terminal window or press __control + C__.




